import requests
import json
import re
from .config import WRITER_PROMPT, CRITIC_PROMPT, GEMINI_API_KEY

MODEL_NAMES = ["gemini-2.5-flash-lite", "gemini-2.0-flash-lite-001", "gemini-2.0-flash-lite", "gemini-flash-lite-latest", "gemini-1.5-flash-8b"]

import time

def call_gemini_api(model_name, prompt):
    """
    Calls the Gemini REST API directly.
    """
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={GEMINI_API_KEY}"
    headers = {'Content-Type': 'application/json'}
    data = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        
        # Handle Rate Limiting (429)
        if response.status_code == 429:
            print(f"Rate limit hit for {model_name}. Waiting 60 seconds...")
            time.sleep(60)
            # Retry once
            response = requests.post(url, headers=headers, json=data)
            
        response.raise_for_status()
        result = response.json()
        
        # Extract text from response
        if 'candidates' in result and result['candidates']:
            content = result['candidates'][0]['content']['parts'][0]['text']
            return content
        else:
            print(f"Unexpected response format from {model_name}: {result}")
            return None
            
    except Exception as e:
        print(f"Error calling {model_name}: {e}")
        try:
             if response.status_code != 200:
                 print(f"Response: {response.text}")
        except:
            pass
        return None

def generate_post(article_text):
    """
    Generates a draft post using Gemini, trying multiple models via REST API.
    """
    for model_name in MODEL_NAMES:
        full_prompt = f"{WRITER_PROMPT}\n\nТекст статьи:\n{article_text}"
        result = call_gemini_api(model_name, full_prompt)
        if result:
            print(f"Successfully generated using {model_name}")
            return result.strip()
            
    print("All models failed to generate post.")
    return None

def critique_post(draft_post):
    """
    Critiques the draft post and returns a score (0-10).
    """
    for model_name in MODEL_NAMES:
        full_prompt = f"{CRITIC_PROMPT}\n\nЧерновик поста:\n{draft_post}"
        result = call_gemini_api(model_name, full_prompt)
        if result:
            text_score = result.strip()
            # Parse the score
            match = re.search(r'\d+', text_score)
            if match:
                return int(match.group())
            return 0
            
    print("All models failed to critique post.")
    return 0
